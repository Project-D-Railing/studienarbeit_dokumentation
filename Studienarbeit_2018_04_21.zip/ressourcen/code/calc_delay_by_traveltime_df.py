def calc_delay_by_traveltime_df(train_stop_from_df, train_stop_to_df):
    """
    Calculates the delay that has been caused by the travel of the train.
    Positive value means, that the travel time caused additional delay.
    Negative value means, that the travel time decreased the delay.
    :param train_stop_from_df: Pandas dataframe. Input for the train stop the train comes from.
    :param train_stop_to_df: Pandas dataframe. Input for the train stop the train arrives at.
    :return: Returns a pandas dataframe with columns 'delay_by_traveltime', 'ttsid_from', 'ttsid_to'.
    """
    if train_stop_from_df is None:
        ttsid_from = None
    else:
        ttsid_from = train_stop_from_df["ttsid"].iloc[0]

    if train_stop_to_df is None:
        ttsid_to = None
    else:
        ttsid_to = train_stop_to_df["ttsid"].iloc[0]

    if train_stop_from_df is None or train_stop_to_df is None:
        delay = pd.NaT
    else:
        traveltime_real = calc_traveltime_real_df(train_stop_from_df, train_stop_to_df)["traveltime_real"].iloc[0]
        traveltime_scheduled = calc_traveltime_scheduled_df(train_stop_from_df, train_stop_to_df)["traveltime_scheduled"].iloc[0]
        delay = traveltime_real - traveltime_scheduled

    result = pd.DataFrame(
        data=[[delay, ttsid_from, ttsid_to]],
        columns=["delay_by_traveltime", "ttsid_from", "ttsid_to"])
    return result