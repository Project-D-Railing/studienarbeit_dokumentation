# labels for table "time table stops" (named "zuege" in database)
TABLE_LABELS_TTS = ["id", "ttsid", "dailytripid", 
    "yymmddhhmm", "stopindex", "zugverkehrstyp", "zugtyp",
    "zugowner", "zugklasse", "zugnummer", "zugnummerfull",
    "linie", "evanr", "arzeitsoll", "arzeitist", "dpzeitsoll",
    "dpzeitist", "gleissoll", "gleisist", "datum",
    "streckengeplanthash", "streckenchangedhash", "zugstatus"]

def _get_tts_by_ttsid_query(self, ttsid):
    query = "SELECT * FROM zuege WHERE zuege.zugid = \"{}\"" \
        .format(ttsid)
    result = self._do_query(query)
    return result

def get_tts_by_ttsid(self, ttsid):
    """
    Retrieves full row of database table by given 'ttsid' (named 'zugid' in database).
    """
    result = self._get_tts_by_ttsid_query(ttsid)
    result_df = pd.DataFrame(data=list(result), columns=TABLE_LABELS_TTS)
    return result_df