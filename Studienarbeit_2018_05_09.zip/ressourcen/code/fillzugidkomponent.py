import query_suite_pandas as qsq
# open sql connecion
qs = qsq.QuerySuite("app_config.json", "configuration", 5000)
# open missing id file
missing_IDs = open("missing_ids.txt", "a", encoding='utf-8-sig', newline='\r\n')

zugid = qs.get_max_id()
first_id = zugid["minid"][0]
last_id = int(zugid["maxid"][0]/2)
for actual_id in reversed(range(17640854, last_id)):
    try:
        temp = qs.get_ttsid_by_id(actual_id)
    except ConnectionResetError:
        print("connection Failed try to reconnect")
        qs.setup_connection("app_config.json", "configuration")
        try:
            temp = qs.get_ttsid_by_id(actual_id)
        except ConnectionResetError:
            print("cant reconnect to server")
            break

    # if ID is not available write id in File
    if temp.empty:
            print("actual id {} is empty".format(actual_id))
            missing_IDs.write('{}\n'.format(actual_id))
            missing_IDs.flush()
    else:
    # check if id is already filled
        if temp["stopid"][0] is None:
            # split zugid in komponents
            zugid = temp["ttsid"][0]
            print("actual id {} \t zugid: {}\n\r".format(actual_id, zugid))
            zugid = zugid.split("-")
            # if first komponent is empty dailytripid was negative
            try:
                if zugid[0] == "":
                    zugid[1] = int(zugid[1]) * (-1)
                    qs.insert_3tuple_with_id(actual_id, zugid[1], zugid[2], zugid[3])
                else:
                    qs.insert_3tuple_with_id(actual_id, (zugid[0]), zugid[1], zugid[2])
            except ConnectionResetError:
                # try again at error
                print("connection Failed try to reconnect")
                qs.setup_connection("app_config.json", "configuration")
                try:
                    if zugid[0] == "":
                        zugid[1] = int(zugid[1]) * (-1)
                        qs.insert_3tuple_with_id(actual_id, zugid[1], zugid[2], zugid[3])
                    else:
                        qs.insert_3tuple_with_id(actual_id, (zugid[0]), zugid[1], zugid[2])
                except ConnectionResetError:
                    pass
        else:
            print("actual id {} is already filled".format(actual_id))
            pass
# close missing id file
missing_IDs.close()
# close sql connection
qs.disconnect()

